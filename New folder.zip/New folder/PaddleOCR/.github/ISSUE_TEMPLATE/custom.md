---
name: Issue template
about: Issue template for code error.
title: ''
labels: ''
assignees: ''

---

请提供下述完整信息以便快速定位问题/Please provide the following information to quickly locate the problem

- 系统环境/System Environment：
- 版本号/Version：Paddle：  PaddleOCR： 问题相关组件/Related components：
- 运行指令/Command Code：
- 完整报错/Complete Error Message：
