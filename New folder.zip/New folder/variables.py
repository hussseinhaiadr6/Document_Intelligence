Path="C:/Users/HHR6/PycharmProjects/"
def get_path():
    return Path